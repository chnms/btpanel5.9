#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
LANG=en_US.UTF-8
public_file=/www/server/panel/install/public.sh
if [ ! -f $public_file ];then
	wget -O $public_file https://raw.githubusercontent.com/chnms/btpanel/blob/master/public.sh -T 5;
fi
. $public_file

download_Url=$NODE_URL
btsb_Url=https://raw.githubusercontent.com/chnms/btpanel/blob/master
setup_path=/www
version=$1

pcreRpm=`rpm -qa |grep bt-pcre`
if [ "${pcreRpm}" != "" ];then
	rpm -e bt-pcre
	yum reinstall pcre pcre-devel -y
fi


if [ "$version" = '' ];then
	updateApi=https://www.bt.cn/Api/updateLinux
	if [ -f /www/server/panel/plugin/beta/config.conf ];then
		updateApi=https://www.bt.cn/Api/updateLinuxBeta
	fi
	version=`/usr/local/curl/bin/curl $updateApi 2>/dev/null|grep -Po '"version":".*?"'|grep -Po '[0-9\.]+'`
fi

if [ "$version" = '' ];then
	version=`cat /www/server/panel/class/common.py|grep "\.version"|awk '{print $3}'|sed 's/"//g'`
	version=${version:0:-1}
fi

if [ "$version" = '' ];then
	echo '版本号获取失败,请手动在第一个参数传入!';
	exit;
fi
wget -T 5 -O panel.zip $btsb_Url/install/update/LinuxPanel-5.9.2_pro.zip
unzip -o panel.zip -d $setup_path/server/ > /dev/null
rm -f panel.zip
cd $setup_path/server/panel/
rm -f $setup_path/server/panel/data/templates.pl
check_bt=`cat /etc/init.d/bt`
if [ "${check_bt}" = "" ];then
	rm -f /etc/init.d/bt
	wget -O /etc/init.d/bt $download_Url/install/src/bt.init -T 10
	chmod +x /etc/init.d/bt
fi
if [ ! -f "/etc/init.d/bt" ]; then
	wget -O /etc/init.d/bt $download_Url/install/src/bt.init -T 10
	chmod +x /etc/init.d/bt
fi
sleep 1 && service bt restart > /dev/null 2>&1 &
echo "====================================="

iptables -A INPUT -p tcp --dport 58888 -j ACCEPT
/etc/rc.d/init.d/iptables save
/etc/init.d/iptables restart

/sbin/iptables -I INPUT -p tcp --dport 58888 -j ACCEPT
/etc/init.d/iptables save
service iptables restart

echo "已成功升级到5.9.2专业版";
/etc/init.d/bt restart
echo "为了保障本机安全性，从现在起开心版面板端口为:58888";
echo "若面板无法访问，请放行安全组，以及关闭机器的防火墙！";
echo -e "\033[31m该界面说明脚本已经执行完毕，欢迎使用！ \033[0m"  
rm -rf update.sh


